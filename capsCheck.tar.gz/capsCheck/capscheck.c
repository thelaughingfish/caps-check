#include "capscheck.h"

/**
Objective:
Count the number of capital words detected. Print the count and then print the words counted.
**/

int lengthdog();

int main(int argc, char **argv) {

	if(argv[1] == NULL){
		printf("Not enough arguments entered. u dun goof'd, boi\n");
		return 0;
	}

	char value;
	int i, j, k=0;	//i = argument traverser
					//j = letter (in an argument) traverser
					//k = capWords[] index
	int count;
	int stringLength;
	int capWords[argc];		//array for holding the argument # that the 
							//capital words are located at

	for(i = 1;i<argc;i++){	//traverses the arguments
		stringLength = lengthdog(argv[i]);	//counts the length of the string in an argument

		for(j = 0;j<stringLength;j++){	//traverses the string in an argument
			value = argv[i][j];			// = the char of argument 'i' at index 'j'

			if((value >= 65) && (value <= 90)){	//if ascii value is capital ascii, return "capital detected"
				count++;				//capital detected
				capWords[k] = i;		//add argument location of detected capital word
				k++;					//increment to next array index
				break;
			}
		}
	}

	printf("%i Word(s) with Capital Letters Detected\n", count);

	int l = 0;

	while (l != count) {				//if(l == count) nothing printed
										//if(l != count) we start print cap words

		int argLoc = capWords[l];				//argument location that holds the capital word
		stringLength = lengthdog(argv[argLoc]);	//used to terminate once the end of string in arg is reached
		for(j = 0; j<stringLength; j++){		//used to traverse the word in the argument
			printf("%c", argv[argLoc][j]);
		}
		printf("\n");	//going to next line to prepare for next word
		l++;	//to go to next argument that has a cap
	}

}

int lengthdog(char s[]){
	int i = 0;

	while(s[i] != '\0') {
		i++;
	}

	return i;
}